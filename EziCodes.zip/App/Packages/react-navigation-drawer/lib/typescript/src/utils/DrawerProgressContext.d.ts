import * as React from 'react';
import Animated from 'react-native-reanimated';
declare const _default: React.Context<Animated.Node<number> | null>;
export default _default;
