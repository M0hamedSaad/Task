import * as React from 'react';
declare const _default: React.Context<React.RefObject<any> | null>;
export default _default;
