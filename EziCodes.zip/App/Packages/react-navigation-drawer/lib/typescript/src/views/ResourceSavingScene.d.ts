import * as React from 'react';
declare type Props = {
    isVisible: boolean;
    children: React.ReactNode;
    style?: any;
};
export default class ResourceSavingScene extends React.Component<Props> {
    render(): JSX.Element;
}
export {};
