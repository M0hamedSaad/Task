export declare const supportsImprovedSpringAnimation: () => boolean;
