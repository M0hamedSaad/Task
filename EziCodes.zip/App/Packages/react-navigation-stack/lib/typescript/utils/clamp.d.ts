export default function clamp(min: number, value: number, max: number): number;
