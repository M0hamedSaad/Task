import * as React from 'react';
import { PanGestureHandler } from 'react-native-gesture-handler';
declare const _default: React.Context<React.Ref<PanGestureHandler>>;
export default _default;
