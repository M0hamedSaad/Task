/// <reference types="react" />
declare type Props = {
    tintColor: string;
};
export default function BackButton({ tintColor }: Props): JSX.Element;
export {};
