import styles from './style';
import React, { Component } from 'react'
import { Text, View, ScrollView, FlatList } from 'react-native'
import { withNavigation } from "react-navigation";
import Image from 'react-native-remote-svg'
import { widthPercentageToDP as wp, heightPercentageToDP as hp } from 'react-native-responsive-screen';

const Data = [{ Key: '1' }, { Key: '2' }, { Key: '3' }]

class Home extends Component {

  componentDidMount() {
    console.ignoredYellowBox = [
      'Setting a timer'
    ];
    console.disableYellowBox = true;
  }
  render() {
    return (
      <View style={styles.container}>
        <ScrollView >
          <View>
            <View style={styles.row}>
              <View style={styles.viewIconBack}>
                <Image style={styles.back} source={require('../../../Images/back.svg')} />
              </View>

              <View style={styles.header}>
                <View>
                  <View style={styles.titleRow}>
                    <Text style={styles.txt}>الرياض</Text>
                    <View style={styles.viewIconArrow}>
                      <Image style={styles.arrow} source={require('../../../Images/arrow.svg')} />
                    </View>
                    <Text style={styles.txt}>جدة</Text>
                  </View>
                  <Text style={styles.txt1}>الإثنين 15 أكتوبر 2019</Text>
                </View>

                <View style={styles.titleRow1}>
                  <Image style={styles.details} source={require('../../../Images/help.svg')} />
                  <Text style={styles.txt}>تفاصيل الطلب</Text>

                </View>
              </View>
            </View>

            <View style={styles.titleRow2}>
              <Text style={styles.txt2}>في انتظار العروض (13) : 04:23</Text>
              <View style={styles.cancelRequestView}>
                <Text style={styles.txt}>إلغاء الطلب</Text>
              </View>
            </View>

            <View style={styles.Table}>
              <View style={styles.txtViewTable}>
                <Text style={styles.txt3}>فئة السيارة</Text>
              </View>
              <View style={styles.viewIconDown}>
                <Image style={styles.icontable} source={require('../../../Images/down.svg')} />
              </View>
              <View style={styles.line} />

              <View style={styles.txtViewTable}>
                <Text style={styles.txt3}>الأقل سعر</Text>
              </View>
              <View style={styles.viewIconDown}>
                <Image style={styles.icontable} source={require('../../../Images/upDown.svg')} />
              </View>
              <View style={styles.line} />

              <View style={styles.txtViewTable}>
                <Text style={styles.txt3}>التصفية(30)</Text>
              </View>
              <View style={styles.viewIconDown}>
                <Image style={styles.icontable} source={require('../../../Images/filter.svg')} />
              </View>

            </View>
<View style={styles.lineGreen}/>
            <View style={{ backgroundColor: '#F1F4F2' }}>

              <FlatList
                data={Data}
                numColumns={1}
                style={{ paddingHorizontal: 5, }}
                contentContainerStyle={styles.listContainer}
                keyExtractor={item => item.Key}
                showsHorizontalScrollIndicator={false}
                renderItem={({ item }) => {
                  return (
                    <View style={styles.menuBox}>
                      <View style={styles.ViewImageIssue}>

                        <View style={styles.view1}>
                          <Text style={styles.txt4}>ريال</Text>
                          <View style={styles.col}>
                            <Text style={styles.num} >260</Text>
                            <Text style={styles.num1} >500 ريال </Text>
                          </View>

                          <View style={styles.view2}>

                            <View style={styles.view3}>
                              <Text style={styles.txt5} >عبدالوهاب احمد</Text>
                              <View style={styles.view4}>
                                <Text style={styles.txt6}>4.7</Text>
                                <Image style={styles.star} source={require('../../../Images/star.svg')} />
                              </View>
                            </View>

                            <View style={styles.view5}>
                              <Image style={styles.user} source={require('../../../Images/help.svg')} />
                            </View>
                          </View>

                        </View>
                        <View style={styles.view6}>
                          <View style={styles.view7}>
                            <Image style={styles.icon} source={require('../../../Images/info.svg')} />
                            <Text style={styles.txt7}>6 شنط</Text>
                            <Image style={styles.icon1} source={require('../../../Images/bag.svg')} />
                            <Text style={styles.txt7} >7 مقاعد</Text>
                            <Image style={styles.icon2} source={require('../../../Images/man.svg')} />
                            <Text style={styles.txt8}>فورد إكسبلوورر</Text>
                          </View>

                        </View>
                        <View style={styles.view8}>
                          <Image style={styles.icon} source={require('../../../Images/video.svg')} />
                          <Text>  </Text>
                          <Image style={styles.icon} source={require('../../../Images/wifi.svg')} />
                          <Image style={styles.icon} source={require('../../../Images/nosmoke.svg')} />
                          <Image style={styles.icon} source={require('../../../Images/charge.svg')} />
                          <Image style={styles.icon} source={require('../../../Images/coffe.svg')} />
                          <Text style={styles.txt9}>سيارة كاملة</Text>

                        </View>
                      </View>

                    </View>
                  )
                }} />
              <View style={styles.height} />

            </View>


          </View>
        </ScrollView>
        <View style={styles.footer}  >
          <View style={styles.btnFooter}>
            <Image style={styles.giftIcon} source={require('../../../Images/gift.svg')} />

            <Text style={styles.txt10}>كود خصم !</Text>
          </View>

          <View style={styles.btnFooter1}>
            <View style={styles.cyrcle} />
            <View>
              <Text style={styles.txt10}>كود خصم !</Text>
              <View style={styles.titleRow3}>
                <Text style={styles.txt11}>الرياض</Text>
                <View style={styles.viewIconArrow2}>
                  <Image style={styles.arrow} source={require('../../../Images/arrow.svg')} />
                </View>
                <Text style={styles.txt11}>جدة</Text>
              </View>
            </View>
<View style={styles.goIconView}>
            <Image style={styles.giftIcon} source={require('../../../Images/go.svg')} />
            </View>
          </View>

        </View>
      </View>

    );
  }
}
export default withNavigation(Home);






